import { io } from "socket.io-client";

const socket = io("http://localhost:3000");

socket.on("connect", () => {
  console.log("Connected:", socket.id);

  // 서버 생성 또는 접속
  const roomID = "my-room-id";
  socket.emit("create", roomID);


  socket.on("created", (roomID: string) => {
    window.location.href = `/room?roomid=${roomID}`;
  });

  // 서버 접속
  // socket.emit("join", roomID);

  // 메시지 전송
  socket.emit("message", roomID, "Hello!");

  socket.on("message", (message: string) => {
    console.log("Received message:", message);
  });

  socket.on("error", (error: string) => {
    console.error("Error:", error);
  });
});

  
socket.on("joined", (roomID) => {
    window.location.href = `/room?roomid=${roomID}`;
  });
  
  socket.on("error", (message) => {
    alert(message);
  });


const joinRoomButton = document.getElementById("joinRoom");
const joinRoomInput = document.getElementById("joinRoomID");

if (joinRoomButton && joinRoomInput) {
    joinRoomButton.addEventListener("click", () => {
        const roomID = document.getElementById("joinRoomID") as HTMLInputElement;

        if (roomID) {
          socket.emit("join", roomID);
        } 
        else {
          alert("Please enter a valid room ID");
        }
      });
  } 
  else {
    console.error("Error: joinRoomButton or joinRoomInput element not found");
  }
