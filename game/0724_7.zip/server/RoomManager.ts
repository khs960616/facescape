
interface Room {
  id: string;
}

class RoomManager {
  private rooms: Map<string, Room>;

  constructor() {
    this.rooms = new Map<string, Room>();
  }

  createRoom(): string {
    const id = Math.random().toString(36).substring(7);
    const room = { id };
    this.rooms.set(id, room);
    return id;
  }

  exists(id: string): boolean {
    return this.rooms.has(id);
  }
}

export const roomManager = new RoomManager();