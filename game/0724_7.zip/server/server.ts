import express from "express";
import { Server } from "socket.io";
import { createServer } from "http";
import { roomManager } from "./RoomManager";
import path from "path";


const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {});

app.use((req, res, next) => {
    if (req.path.endsWith('.js')) {
        res.setHeader('Content-Type', 'application/javascript');
    }
    next();
  });
  
app.use(express.static(path.join(__dirname, "../client")));

app.get("/create-room", (req, res) => {
    const roomID = roomManager.createRoom();
    res.send(roomID);
  });

  app.get("/room", (req, res) => {
    const roomID = req.query.roomid;
    if (roomManager.exists(roomID as string)) {
      // 필요한 경우 roomid를 이용해 페이지를 렌더링합니다.
      res.sendFile(path.join(__dirname, "../client/room.html"));
    } else {
      res.status(404).send("Room not found");
    }
  });



io.on("connection", (socket) => {
  console.log(`Connected: ${socket.id}`);


  socket.on("join", (roomID: string) => {
    if (roomManager.exists(roomID)) {
      socket.join(roomID);
      socket.emit("joined", roomID);
    } 
    else {
      socket.emit("error", "Room not found");
    }
  });

  socket.on("disconnect", () => {
    console.log(`Disconnected: ${socket.id}`);
  });

  socket.on("create", () => {
    const roomID = roomManager.createRoom();
    socket.join(roomID);
    socket.emit("created", roomID);
  });

  socket.on("join", (roomID: string) => {
    if (roomManager.exists(roomID)) {
      socket.join(roomID);
    } 
    else {
      socket.emit("error", "Room not found");
    }
  });

  socket.on("message", (roomID: string, message: string) => {
    socket.to(roomID).emit("message", message);
  });
});

const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => {
  console.log("Server started on port", PORT);
});
